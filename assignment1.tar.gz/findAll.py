import shelve,json,os,time,sys
from ladder import *


with open('dictionary.json') as data_file:
    data = json.load(data_file)

if(os.path.exists('dict')):
    dict = shelve.open('dict');
    dict = dict['dict'];
else:
    dict = {};
    for word in data.keys():
        if len(word) not in dict.keys():
            dict[len(word)] = [];
        dict[len(word)].append(word);
    dictFile = shelve.open('dict');
    dictFile['dict'] = dict;


stat = shelve.open('stat');
stat["list"] = [];

for key in dict.keys():
    for first in dict[key]:
        for second in dict[key]:
            print("WORD LADDER FOR ",first,"---->",second);
            visited = [];
            elapsed = time.clock();
            visited.append(first);
            dfs(first,second,dict[len(first)],visited,elapsed);
            if(visited[0] == first and visited[len(visited)-1] == second):
                print("Sequence:",visited)
                stat["list"].append([first,second,len(visited)])
            else:
                print("The Solution doesnt exist")


stat.close();                

import shelve,json,os,time,sys
from ladder import *


with open('dictionary.json') as data_file:
    data = json.load(data_file)

if(os.path.exists('dict')):
    dict = shelve.open('dict');
    dict = dict['dict'];
else:
    dict = {};
    for word in data.keys():
        if len(word) not in dict.keys():
            dict[len(word)] = [];
        dict[len(word)].append(word);
    dictFile = shelve.open('dict');
    dictFile['dict'] = dict;




first = input("Enter First Word:");
dest  = input("Enter Dest WordL");

if(first in dict[len(first)] and dest in dict[len(dest)]):
    if(len(first) != len(dest)):
        print("Please enter words of same length")
    else:
        visited = [];
        elapsed = time.clock();
        visited.append(first);
        elapsed = dfs(first,dest,dict[len(first)],visited,elapsed);

        if(visited[0] == first and visited[len(visited)-1] == dest):
            print("Sequence:",visited)
        else:
            print("The Solution doesnt exist")

else:
    print("These words don't exist in dictionary")

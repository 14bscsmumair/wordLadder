import shelve,json,os,time,sys
sys.setrecursionlimit(100000000);
from operator import itemgetter

prevCost = 0;
elapsed = 0;
def hamdist(str1, str2):
    diffs = 0
    for ch1, ch2 in zip(str1, str2):
            if ch1 != ch2:
                    diffs += 1
    return diffs

def dfs(first,end,wordList,visited,elapsed):

    global prevCost;
    frontier = [];  #  List of nodes to be visited.
    for word in wordList:
        hamdist1 = hamdist(first,word);
        if hamdist1 == 1 and word not in visited and "-" not in word:
            frontier.append([word,hamdist(word,end) + prevCost]);


    frontier = sorted(frontier, key=itemgetter(1))
    for wordInfo in frontier:
        word,cost = frontier.pop(0);
        runtime = time.clock() - elapsed;
        if(end not in visited and runtime < 0.7):
            visited.append(word);
            prevCost += cost;
            dfs(word,end,wordList,visited,elapsed);
        else:
            break;
            return;
